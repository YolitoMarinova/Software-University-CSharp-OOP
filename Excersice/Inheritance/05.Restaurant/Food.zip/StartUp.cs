﻿using Restaurant.Beverage;
using Restaurant.Food;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main()
        {
           
        }
    }
}