﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _05.GreedyTimes
{
    public class GreedyTimes
    {
        static void Main(string[] args)
        {
            Starter starter = new Starter();
            starter.Start();
        }
    }
}